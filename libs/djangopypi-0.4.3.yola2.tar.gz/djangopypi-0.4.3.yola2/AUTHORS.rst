Authors/Contributors
--------------------

* Ask Solem <askh@opera.com>
* Rune Halvorsen <runeh@opera.com>
* Russell Sim <russell.sim@gmail.com>
* Brian Rosner <brosner@gmail.com>
* Hugo Lopes Tavares <hltbra@gmail.com>
* Sverre Johansen <sverre.johansen@gmail.com>
* Bo Shi <bs@alum.mit.edu>
* Carl Meyer <carl@dirtcircle.com>
* Vinícius das Chagas Silva <vinimaster@gmail.com>
* Vanderson Mota dos Santos <vanderson.mota@gmail.com>
* Stefan Foulis <stefan.foulis@gmail.com>
* Michael Richardson <michael@michaelrichardson.me>
* Benjamin Liles <benliles@gmail.com>
* Halldór Rúnarsson <halldor89@gmail.com>
* Jannis Leidel <jannis@leidel.info>
* Sebastien Fievet <zyegfryed@gmail.com>
